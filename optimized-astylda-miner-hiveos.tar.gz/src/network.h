#pragma once

#include <string>
#include <memory>
#include <curl/curl.h>
#include "qhash.h"

class NetworkManager {
public:
    NetworkManager(const std::string& url, const std::string& user, const std::string& pass);
    ~NetworkManager();

    bool connect();
    void disconnect();
    bool getWork(QHashWork& work);
    bool submitShare(const QHashResult& result);
    void keepAlive();
    void processEvents();

private:
    std::string url_;
    std::string user_;
    std::string pass_;
    CURL* curl_;
    bool connected_;
    
    // Stratum протокол
    int stratum_id_;
    std::string session_id_;
    
    // Вспомогательные функции
    bool subscribe();
    bool authorize();
    bool submit(const std::string& method, const std::string& params);
    static size_t writeCallback(void* contents, size_t size, size_t nmemb, std::string* userp);
}; 