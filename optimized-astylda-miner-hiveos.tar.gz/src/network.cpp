#include "network.h"
#include <iostream>
#include <sstream>

NetworkManager::NetworkManager(const std::string& url, const std::string& user, const std::string& pass)
    : url_(url), user_(user), pass_(pass), curl_(nullptr), connected_(false), stratum_id_(1) {
    
    curl_global_init(CURL_GLOBAL_ALL);
    curl_ = curl_easy_init();
    
    if (curl_) {
        curl_easy_setopt(curl_, CURLOPT_TIMEOUT, 30L);
        curl_easy_setopt(curl_, CURLOPT_CONNECTTIMEOUT, 10L);
        curl_easy_setopt(curl_, CURLOPT_WRITEFUNCTION, writeCallback);
    }
}

NetworkManager::~NetworkManager() {
    disconnect();
    if (curl_) {
        curl_easy_cleanup(curl_);
    }
    curl_global_cleanup();
}

bool NetworkManager::connect() {
    std::cout << "Подключение к пулу: " << url_ << std::endl;
    
    if (!curl_) {
        std::cerr << "Ошибка инициализации CURL" << std::endl;
        return false;
    }
    
    // Подписка на Stratum
    if (!subscribe()) {
        std::cerr << "Ошибка подписки на Stratum" << std::endl;
        return false;
    }
    
    // Авторизация
    if (!authorize()) {
        std::cerr << "Ошибка авторизации" << std::endl;
        return false;
    }
    
    connected_ = true;
    std::cout << "✓ Подключение к пулу установлено" << std::endl;
    return true;
}

void NetworkManager::disconnect() {
    if (connected_) {
        std::cout << "Отключение от пула..." << std::endl;
        connected_ = false;
    }
}

bool NetworkManager::getWork(QHashWork& work) {
    if (!connected_) {
        return false;
    }
    
    // В реальной реализации здесь должен быть запрос работы от пула
    // Для демонстрации создаем тестовую работу
    
    // Заполнение заголовка блока
    std::memset(work.header, 0, 80);
    work.header[0] = 0x01; // Версия
    work.timestamp = std::time(nullptr);
    std::memcpy(&work.header[68], &work.timestamp, 4);
    
    // Установка target (сложность)
    std::memset(work.target, 0xFF, 32);
    work.target[0] = 0x00; // Простая сложность для тестирования
    
    work.difficulty = 1.0;
    
    return true;
}

bool NetworkManager::submitShare(const QHashResult& result) {
    if (!connected_) {
        return false;
    }
    
    // Подготовка данных для отправки
    std::stringstream ss;
    ss << "{\"method\":\"mining.submit\",\"params\":[\"" << user_ << "\",\"";
    
    // Добавление job_id (в реальной реализации должен быть получен от пула)
    ss << "job_id" << "\",\"";
    
    // Добавление extraNonce2 (в реальной реализации должен быть получен от пула)
    ss << "00000000" << "\",\"";
    
    // Добавление ntime
    ss << std::hex << std::time(nullptr) << "\",\"";
    
    // Добавление nonce
    ss << std::hex << result.nonce << "\"],\"id\":" << stratum_id_++ << "}";
    
    return submit("mining.submit", ss.str());
}

void NetworkManager::keepAlive() {
    if (!connected_) {
        return;
    }
    
    // Отправка ping для поддержания соединения
    static int ping_counter = 0;
    if (++ping_counter >= 30) { // Каждые 30 секунд
        submit("mining.noop", "{}");
        ping_counter = 0;
    }
}

void NetworkManager::processEvents() {
    // Обработка событий от пула (в реальной реализации)
    // Здесь должна быть обработка уведомлений о новых блоках, изменениях сложности и т.д.
}

bool NetworkManager::subscribe() {
    std::string params = "{\"method\":\"mining.subscribe\",\"params\":[\"OptimizedAstyldaMiner/2.0\"],\"id\":1}";
    
    std::string response;
    curl_easy_setopt(curl_, CURLOPT_URL, url_.c_str());
    curl_easy_setopt(curl_, CURLOPT_POSTFIELDS, params.c_str());
    curl_easy_setopt(curl_, CURLOPT_WRITEDATA, &response);
    
    CURLcode res = curl_easy_perform(curl_);
    if (res != CURLE_OK) {
        std::cerr << "Ошибка CURL: " << curl_easy_strerror(res) << std::endl;
        return false;
    }
    
    // Парсинг ответа (упрощенно)
    std::cout << "Ответ от пула: " << response << std::endl;
    
    return true;
}

bool NetworkManager::authorize() {
    std::stringstream ss;
    ss << "{\"method\":\"mining.authorize\",\"params\":[\"" << user_ << "\",\"" << pass_ << "\"],\"id\":2}";
    
    std::string response;
    curl_easy_setopt(curl_, CURLOPT_POSTFIELDS, ss.str().c_str());
    curl_easy_setopt(curl_, CURLOPT_WRITEDATA, &response);
    
    CURLcode res = curl_easy_perform(curl_);
    if (res != CURLE_OK) {
        std::cerr << "Ошибка авторизации: " << curl_easy_strerror(res) << std::endl;
        return false;
    }
    
    // Парсинг ответа (упрощенно)
    std::cout << "Ответ авторизации: " << response << std::endl;
    
    return true;
}

bool NetworkManager::submit(const std::string& method, const std::string& params) {
    (void)method; // Подавление предупреждения о неиспользуемом параметре
    
    std::string response;
    curl_easy_setopt(curl_, CURLOPT_POSTFIELDS, params.c_str());
    curl_easy_setopt(curl_, CURLOPT_WRITEDATA, &response);
    
    CURLcode res = curl_easy_perform(curl_);
    if (res != CURLE_OK) {
        std::cerr << "Ошибка отправки: " << curl_easy_strerror(res) << std::endl;
        return false;
    }
    
    // Проверка ответа
    if (response.find("\"result\":true") != std::string::npos) {
        return true;
    } else {
        std::cerr << "Ошибка от пула: " << response << std::endl;
        return false;
    }
}

size_t NetworkManager::writeCallback(void* contents, size_t size, size_t nmemb, std::string* userp) {
    userp->append((char*)contents, size * nmemb);
    return size * nmemb;
} 