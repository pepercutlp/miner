#pragma once

#include <string>
#include <vector>

namespace Utils {
    // Функции для работы с CPU affinity
    bool setCPUAffinity(const std::string& mask);
    std::vector<int> parseCPUMask(const std::string& mask);
    
    // Функции для работы с памятью
    size_t getSystemMemory();
    size_t getGPUMemory();
    
    // Функции для логирования
    void log(const std::string& message, const std::string& level = "info");
    void setLogLevel(const std::string& level);
    
    // Функции для валидации
    bool isValidURL(const std::string& url);
    bool isValidWalletAddress(const std::string& address);
    
    // Функции для форматирования
    std::string formatHashrate(double hashrate);
    std::string formatTime(uint64_t seconds);
} 