#pragma once

#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <memory>
#include <chrono>
#include <mutex>

struct MinerConfig {
    std::string algo = "qhash";
    std::string url;
    std::string user;
    std::string pass;
    std::string config_file;
    std::string cpu_affinity;
    std::string log_level = "info";
    std::string log_file;
    
    int threads = 1;
    int gpu_threads = 1;
    int api_port = 4048;
    int gpu_memory = 2048;
    int batch_size = 1024;
    int stats_interval = 30;
    
    bool optimize_memory = false;
    bool disable_dev_fee = false;
};

struct MinerStats {
    std::atomic<uint64_t> shares_accepted{0};
    std::atomic<uint64_t> shares_rejected{0};
    std::atomic<uint64_t> blocks_found{0};
    std::atomic<double> hashrate{0.0};
    std::atomic<uint64_t> uptime{0};
    std::atomic<uint64_t> total_hashes{0};
    std::chrono::steady_clock::time_point start_time;
    
    // Конструктор копирования для atomic
    MinerStats() = default;
    MinerStats(const MinerStats& other) {
        shares_accepted = other.shares_accepted.load();
        shares_rejected = other.shares_rejected.load();
        blocks_found = other.blocks_found.load();
        hashrate = other.hashrate.load();
        uptime = other.uptime.load();
        total_hashes = other.total_hashes.load();
        start_time = other.start_time;
    }
    
    // Оператор присваивания
    MinerStats& operator=(const MinerStats& other) {
        if (this != &other) {
            shares_accepted = other.shares_accepted.load();
            shares_rejected = other.shares_rejected.load();
            blocks_found = other.blocks_found.load();
            hashrate = other.hashrate.load();
            uptime = other.uptime.load();
            total_hashes = other.total_hashes.load();
            start_time = other.start_time;
        }
        return *this;
    }
};

class NetworkManager;
class QHashEngine;
class APIServer;

class Miner {
public:
    explicit Miner(const MinerConfig& config);
    ~Miner();

    void start();
    void stop();
    MinerStats getStats() const;
    
    // Оптимизации
    void setCPUAffinity(const std::string& mask);
    void optimizeMemoryUsage();
    void setGPUMemory(int memory_mb);
    void setBatchSize(int batch_size);

private:
    MinerConfig config_;
    MinerStats stats_;
    std::atomic<bool> running_{false};
    
    std::unique_ptr<NetworkManager> network_;
    std::unique_ptr<QHashEngine> qhash_engine_;
    std::unique_ptr<APIServer> api_server_;
    
    std::vector<std::thread> worker_threads_;
    std::thread stats_thread_;
    std::thread network_thread_;
    
    mutable std::mutex stats_mutex_;
    
    void workerThread(int thread_id);
    void statsThread();
    void networkThread();
    void updateStats();
    void printStats();
}; 