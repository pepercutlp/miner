#!/bin/bash

# Скрипт сбора статистики для optimized-astylda-miner
# Используется в HiveOS для мониторинга

# Проверка наличия jq
if ! command -v jq &> /dev/null; then
    echo "Ошибка: jq не установлен"
    exit 1
fi

# Получение количества GPU
gpu_count=$(nvidia-smi --list-gpus | wc -l)
if [[ $gpu_count -eq 0 ]]; then
    gpu_count=1
fi

# Инициализация массивов
declare -a hashrates
declare -a temps
declare -a fans
declare -a busids

# Сбор статистики с каждого GPU
for ((i = 0; i < gpu_count; i++)); do
    apiPort="4444$i"
    
    # Получение статистики через API
    stats_template=$(echo "summary" | nc -w 5 localhost $apiPort 2>/dev/null | tr -d '\0')
    
    if [[ -n "$stats_template" ]]; then
        # Парсинг статистики (упрощенная версия)
        hashrate=$(echo "$stats_template" | grep -o '"hashrate":[0-9.]*' | cut -d':' -f2 | head -1)
        uptime=$(echo "$stats_template" | grep -o '"uptime":[0-9]*' | cut -d':' -f2 | head -1)
        
        if [[ -n "$hashrate" ]]; then
            hashrates[$i]=$hashrate
        else
            hashrates[$i]=0
        fi
    else
        hashrates[$i]=0
        uptime=0
    fi
    
    # Получение информации о GPU
    gpu_info=$(nvidia-smi --query-gpu=temperature.gpu,fan.speed,pci.bus_id --format=csv,noheader,nounits | sed -n "$((i+1))p")
    if [[ -n "$gpu_info" ]]; then
        temp=$(echo "$gpu_info" | cut -d',' -f1 | tr -d ' ')
        fan=$(echo "$gpu_info" | cut -d',' -f2 | tr -d ' ')
        busid=$(echo "$gpu_info" | cut -d',' -f3 | tr -d ' ')
        
        temps[$i]=$temp
        fans[$i]=$fan
        busids[$i]=$busid
    else
        temps[$i]=0
        fans[$i]=0
        busids[$i]="0000:00:00.0"
    fi
done

# Создание JSON массивов
hr_json="["
temp_json="["
fan_json="["
busid_json="["

for ((i = 0; i < gpu_count; i++)); do
    if [[ $i -gt 0 ]]; then
        hr_json+=","
        temp_json+=","
        fan_json+=","
        busid_json+=","
    fi
    hr_json+="${hashrates[$i]}"
    temp_json+="${temps[$i]}"
    fan_json+="${fans[$i]}"
    busid_json+="\"${busids[$i]}\""
done

hr_json+="]"
temp_json+="]"
fan_json+="]"
busid_json+="]"

# Расчет общего хешрейта
totalKhs=0
for hashrate in "${hashrates[@]}"; do
    totalKhs=$(echo "$totalKhs + $hashrate" | bc -l)
done

# Формирование итоговой статистики
stats=$(jq -nc \
    --arg algo "qhash" \
    --arg ver "$CUSTOM_VERSION" \
    --arg uptime "$uptime" \
    --argjson hs "$hr_json" \
    --arg hs_units "khs" \
    --arg ths "$totalKhs" \
    --argjson bus_numbers "$busid_json" \
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    '{ $hs, $ths, $hs_units, $algo, $ver, $uptime, $bus_numbers, $fan, $temp}')

echo "$stats" 