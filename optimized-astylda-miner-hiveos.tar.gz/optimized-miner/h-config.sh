#!/bin/bash

# Генерация конфигурации для optimized-astylda-miner
# Используется в HiveOS для создания конфигурационного файла

# Проверка обязательных переменных
if [[ -z $CUSTOM_URL ]]; then
    echo "Ошибка: CUSTOM_URL не установлен"
    exit 1
fi

if [[ -z $CUSTOM_TEMPLATE ]]; then
    echo "Ошибка: CUSTOM_TEMPLATE не установлен"
    exit 1
fi

# Создание конфигурации
conf="--algo qhash"
conf+=" --url $CUSTOM_URL"
conf+=" -u $CUSTOM_TEMPLATE"

# Добавление пароля если указан
[[ -n $CUSTOM_PASS ]] && conf+=" -p $CUSTOM_PASS"

# Добавление количества потоков
[[ -n $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

# Запись в файл конфигурации
echo -e "$conf" > $CUSTOM_CONFIG_FILENAME

# Создание дополнительного конфигурационного файла
if [[ -n $CUSTOM_USER_CONFIG ]]; then
    echo -e "$CUSTOM_USER_CONFIG" > $CUSTOM_USER_CONFIG_FILENAME
fi

echo "Конфигурация создана: $CUSTOM_CONFIG_FILENAME"
echo "Содержимое:"
cat $CUSTOM_CONFIG_FILENAME 