# Optimized Astylda Miner для HiveOS

Оптимизированная версия майнера Astylda с улучшенной производительностью и поддержкой HiveOS.

## Особенности

- **Алгоритм:** QHash
- **Оптимизации:** CUDA kernels, memory coalescing, warp-level primitives
- **API:** Встроенный API сервер для мониторинга
- **Многопоточность:** Поддержка множественных GPU
- **HiveOS:** Полная интеграция с HiveOS

## Установка

### Автоматическая установка

```bash
# Скачайте архив и распакуйте
tar -xzf optimized-astylda-miner-hiveos.tar.gz
cd optimized-astylda-miner

# Запустите установку
chmod +x install.sh
sudo ./install.sh
```

### Ручная установка

1. **Установка зависимостей:**
   ```bash
   sudo apt update
   sudo apt install -y build-essential cmake git wget curl \
       libssl-dev libcurl4-openssl-dev libjson-c-dev libgmp-dev \
       libpthread-stubs0-dev bc jq netcat
   ```

2. **Установка CUDA (если не установлена):**
   ```bash
   # Для Ubuntu 20.04
   wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2004/x86_64/cuda-keyring_1.0-1_all.deb
   sudo dpkg -i cuda-keyring_1.0-1_all.deb
   sudo apt update
   sudo apt install -y cuda-toolkit-12-4
   
   # Для Ubuntu 22.04
   wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
   sudo dpkg -i cuda-keyring_1.0-1_all.deb
   sudo apt update
   sudo apt install -y cuda-toolkit-12-4
   ```

3. **Сборка майнера:**
   ```bash
   make clean
   make -j$(nproc)
   ```

4. **Установка в HiveOS:**
   ```bash
   sudo mkdir -p /hive/miners/custom/optimized-astylda
   sudo cp optimized-astylda-miner /hive/miners/custom/optimized-astylda/
   sudo cp h-*.sh /hive/miners/custom/optimized-astylda/
   sudo cp h-manifest.conf /hive/miners/custom/optimized-astylda/
   sudo chmod +x /hive/miners/custom/optimized-astylda/*.sh
   ```

## Использование

### Запуск через HiveOS

1. В веб-интерфейсе HiveOS перейдите в раздел "Miner Configuration"
2. Выберите "Custom Miner"
3. Укажите следующие параметры:
   - **Miner Name:** optimized-astylda
   - **Binary:** optimized-astylda-miner
   - **Config File:** /hive/miners/custom/optimized-astylda/miner.conf
   - **Run Script:** /hive/miners/custom/optimized-astylda/h-run.sh
   - **Stats Script:** /hive/miners/custom/optimized-astylda/h-stats.sh

### Ручной запуск

```bash
cd /hive/miners/custom/optimized-astylda

# Создание конфигурации
export CUSTOM_URL="stratum+tcp://pool.example.com:3333"
export CUSTOM_TEMPLATE="your_wallet_address"
export CUSTOM_PASS="x"
export CUSTOM_CONFIG_FILENAME="/hive/miners/custom/optimized-astylda/miner.conf"
./h-config.sh

# Запуск майнера
./h-run.sh
```

### Параметры командной строки

```bash
./optimized-astylda-miner [опции]

Опции:
  -a, --algo ALGO        Алгоритм (qhash)
  -o, --url URL          URL пула
  -u, --user USER        Имя пользователя/кошелек
  -p, --pass PASS        Пароль
  -t, --threads N        Количество CPU потоков
  --gpu-threads N        Количество GPU потоков
  --api-bind PORT        API порт (по умолчанию: 4048)
  --gpu-memory N         GPU память в MB
  --batch-size N         Размер батча
  --cpu-affinity MASK    Маска CPU affinity
  -h, --help             Показать справку
```

## Мониторинг

### API статистика

Майнер предоставляет API на порту 4048 (по умолчанию):

```bash
# Получение статистики
echo "summary" | nc localhost 4048

# Получение информации о GPU
echo "gpu" | nc localhost 4048

# Получение информации о пуле
echo "pool" | nc localhost 4048
```

### HiveOS статистика

Скрипт `h-stats.sh` автоматически собирает статистику для HiveOS:

```bash
./h-stats.sh
```

## Оптимизации

### GPU оптимизации

- **Memory Coalescing:** Оптимизированный доступ к памяти GPU
- **Warp-level Primitives:** Использование warp-уровневых операций
- **Shared Memory:** Эффективное использование shared memory
- **Half Precision:** Поддержка FP16 для ускорения вычислений

### CPU оптимизации

- **CPU Affinity:** Привязка потоков к конкретным ядрам
- **Memory Layout:** Оптимизированное размещение данных в памяти
- **SIMD Instructions:** Использование векторных инструкций

### Сетевые оптимизации

- **Connection Pooling:** Переиспользование соединений
- **Batch Submissions:** Пакетная отправка шар
- **Keep-alive:** Поддержка keep-alive соединений

## Устранение неполадок

### Ошибки сборки

1. **CUDA не найдена:**
   ```bash
   export PATH=/usr/local/cuda/bin:$PATH
   export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
   ```

2. **Библиотеки не найдены:**
   ```bash
   sudo apt install -y libssl-dev libcurl4-openssl-dev libjson-c-dev libgmp-dev
   ```

### Ошибки запуска

1. **GPU не обнаружены:**
   ```bash
   nvidia-smi
   # Проверьте драйверы NVIDIA
   ```

2. **Ошибки API:**
   ```bash
   # Проверьте порт
   netstat -tuln | grep 4048
   ```

### Оптимизация производительности

1. **Настройка GPU памяти:**
   ```bash
   ./optimized-astylda-miner --gpu-memory 4096
   ```

2. **Настройка CPU affinity:**
   ```bash
   ./optimized-astylda-miner --cpu-affinity 0x3
   ```

3. **Настройка размера батча:**
   ```bash
   ./optimized-astylda-miner --batch-size 2048
   ```

## Логи

Логи майнера сохраняются в:
- `/var/log/optimized-astylda-miner*.log` - основные логи
- `/var/log/miner/optimized-astylda.log` - логи HiveOS

## Поддержка

При возникновении проблем:

1. Проверьте логи: `tail -f /var/log/optimized-astylda-miner*.log`
2. Проверьте API: `echo "summary" | nc localhost 4048`
3. Проверьте GPU: `nvidia-smi`
4. Проверьте сеть: `ping pool.example.com`

## Версии

- **v1.0.0:** Первоначальная версия с базовыми оптимизациями
- **v1.1.0:** Добавлены CUDA оптимизации
- **v1.2.0:** Улучшена интеграция с HiveOS 