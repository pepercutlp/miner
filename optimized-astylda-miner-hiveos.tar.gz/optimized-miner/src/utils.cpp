#include "utils.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <regex>
#include <sched.h>
#include <chrono>
#include <ctime>

// Заглушка для sysinfo на macOS
#ifdef __APPLE__
#include <sys/sysctl.h>
#else
#include <sys/sysinfo.h>
#endif

namespace Utils {

bool setCPUAffinity(const std::string& mask) {
    auto cpus = parseCPUMask(mask);
    if (cpus.empty()) {
        return false;
    }
    
#ifdef __APPLE__
    // macOS не поддерживает sched_setaffinity, возвращаем true для совместимости
    std::cout << "CPU affinity не поддерживается на macOS" << std::endl;
    return true;
#else
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    
    for (int cpu : cpus) {
        CPU_SET(cpu, &cpuset);
    }
    
    return sched_setaffinity(0, sizeof(cpu_set_t), &cpuset) == 0;
#endif
}

std::vector<int> parseCPUMask(const std::string& mask) {
    std::vector<int> cpus;
    
    if (mask.empty()) {
        return cpus;
    }
    
    // Поддержка hex маски (0x3 = CPU 0,1)
    if (mask.substr(0, 2) == "0x") {
        try {
            uint32_t hex_mask = std::stoul(mask, nullptr, 16);
            for (int i = 0; i < 32; ++i) {
                if (hex_mask & (1u << i)) {
                    cpus.push_back(i);
                }
            }
        } catch (...) {
            return cpus;
        }
    } else {
        // Поддержка списка CPU (0,1,2,3)
        std::stringstream ss(mask);
        std::string item;
        while (std::getline(ss, item, ',')) {
            try {
                cpus.push_back(std::stoi(item));
            } catch (...) {
                continue;
            }
        }
    }
    
    return cpus;
}

size_t getSystemMemory() {
#ifdef __APPLE__
    // macOS
    uint64_t memsize;
    size_t len = sizeof(memsize);
    if (sysctlbyname("hw.memsize", &memsize, &len, nullptr, 0) == 0) {
        return memsize;
    }
    return 0;
#else
    // Linux
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        return info.totalram * info.mem_unit;
    }
    return 0;
#endif
}

size_t getGPUMemory() {
    // В реальной реализации здесь должна быть проверка GPU памяти через CUDA
    // Для демонстрации возвращаем фиксированное значение
    return 8ULL * 1024 * 1024 * 1024; // 8GB
}

void log(const std::string& message, const std::string& level) {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    auto tm = *std::localtime(&time_t);
    
    std::cout << std::put_time(&tm, "%Y-%m-%d %H:%M:%S") << " [" << level << "] " << message << std::endl;
}

void setLogLevel(const std::string& level) {
    // В реальной реализации здесь должна быть настройка уровня логирования
    log("Уровень логирования установлен: " + level);
}

bool isValidURL(const std::string& url) {
    std::regex url_regex(R"((https?|stratum\+tcp|stratum\+ssl)://[^\s/$.?#].[^\s]*)");
    return std::regex_match(url, url_regex);
}

bool isValidWalletAddress(const std::string& address) {
    // Простая проверка для демонстрации
    // В реальной реализации должна быть проверка контрольной суммы
    return address.length() >= 26 && address.length() <= 35;
}

std::string formatHashrate(double hashrate) {
    std::stringstream ss;
    
    if (hashrate >= 1000000) {
        ss << std::fixed << std::setprecision(2) << (hashrate / 1000000) << " GH/s";
    } else if (hashrate >= 1000) {
        ss << std::fixed << std::setprecision(2) << (hashrate / 1000) << " MH/s";
    } else {
        ss << std::fixed << std::setprecision(2) << hashrate << " KH/s";
    }
    
    return ss.str();
}

std::string formatTime(uint64_t seconds) {
    uint64_t hours = seconds / 3600;
    uint64_t minutes = (seconds % 3600) / 60;
    uint64_t secs = seconds % 60;
    
    std::stringstream ss;
    
    if (hours > 0) {
        ss << hours << "h ";
    }
    if (minutes > 0 || hours > 0) {
        ss << minutes << "m ";
    }
    ss << secs << "s";
    
    return ss.str();
}

} // namespace Utils 