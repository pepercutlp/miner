#include <iostream>
#include <string>
#include <thread>
#include <signal.h>
#include <getopt.h>
#include "miner.h"
#include "utils.h"

static volatile bool running = true;

void signal_handler(int sig) {
    (void)sig; // Подавление предупреждения о неиспользуемом параметре
    running = false;
    std::cout << "\nПолучен сигнал завершения. Останавливаю майнер..." << std::endl;
}

void print_usage(const char* program_name) {
    std::cout << "Оптимизированный Astylda Miner v2.0\n"
              << "Использование: " << program_name << " [ОПЦИИ]\n\n"
              << "ОСНОВНЫЕ ОПЦИИ:\n"
              << "  -a, --algo=ALGO       Алгоритм майнинга (qhash)\n"
              << "  -o, --url=URL         URL сервера майнинга\n"
              << "  -u, --user=USER       Имя пользователя\n"
              << "  -p, --pass=PASS       Пароль\n"
              << "  -t, --threads=N       Количество потоков CPU\n"
              << "  -g, --gpu-threads=N   Количество потоков GPU\n"
              << "  -b, --api-bind=IP:PORT API интерфейс (по умолчанию 4048)\n"
              << "  -c, --config=FILE     JSON конфигурационный файл\n\n"
              << "ОПТИМИЗАЦИЯ:\n"
              << "  --cpu-affinity=MASK   Привязка к CPU ядрам (0x3 для ядер 0,1)\n"
              << "  --gpu-memory=N        Память GPU в MB\n"
              << "  --batch-size=N        Размер батча для GPU\n"
              << "  --optimize-memory     Оптимизация использования памяти\n"
              << "  --disable-dev-fee     Отключить dev fee (если есть)\n\n"
              << "МОНИТОРИНГ:\n"
              << "  --stats-interval=N    Интервал статистики в секундах\n"
              << "  --log-level=LEVEL     Уровень логирования (debug,info,warn,error)\n"
              << "  --log-file=FILE       Файл для логов\n\n"
              << "ПРИМЕРЫ:\n"
              << "  " << program_name << " -a qhash -o stratum+tcp://pool.example.com:3333 -u wallet -p x -t 8\n"
              << "  " << program_name << " -c config.json --optimize-memory --stats-interval=30\n";
}

int main(int argc, char* argv[]) {
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    MinerConfig config;
    config.algo = "qhash";
    config.threads = std::thread::hardware_concurrency();
    config.gpu_threads = 1;
    config.api_port = 4048;
    config.stats_interval = 30;
    config.log_level = "info";
    config.optimize_memory = false;
    config.disable_dev_fee = false;

    static struct option long_options[] = {
        {"algo", required_argument, 0, 'a'},
        {"url", required_argument, 0, 'o'},
        {"user", required_argument, 0, 'u'},
        {"pass", required_argument, 0, 'p'},
        {"threads", required_argument, 0, 't'},
        {"gpu-threads", required_argument, 0, 'g'},
        {"api-bind", required_argument, 0, 'b'},
        {"config", required_argument, 0, 'c'},
        {"cpu-affinity", required_argument, 0, 0},
        {"gpu-memory", required_argument, 0, 0},
        {"batch-size", required_argument, 0, 0},
        {"optimize-memory", no_argument, 0, 0},
        {"disable-dev-fee", no_argument, 0, 0},
        {"stats-interval", required_argument, 0, 0},
        {"log-level", required_argument, 0, 0},
        {"log-file", required_argument, 0, 0},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int opt;
    int option_index = 0;

    while ((opt = getopt_long(argc, argv, "a:o:u:p:t:g:b:c:h", long_options, &option_index)) != -1) {
        switch (opt) {
            case 'a': config.algo = optarg; break;
            case 'o': config.url = optarg; break;
            case 'u': config.user = optarg; break;
            case 'p': config.pass = optarg; break;
            case 't': config.threads = std::stoi(optarg); break;
            case 'g': config.gpu_threads = std::stoi(optarg); break;
            case 'b': config.api_port = std::stoi(optarg); break;
            case 'c': config.config_file = optarg; break;
            case 'h': print_usage(argv[0]); return 0;
            case 0:
                if (strcmp(long_options[option_index].name, "cpu-affinity") == 0) {
                    config.cpu_affinity = optarg;
                } else if (strcmp(long_options[option_index].name, "gpu-memory") == 0) {
                    config.gpu_memory = std::stoi(optarg);
                } else if (strcmp(long_options[option_index].name, "batch-size") == 0) {
                    config.batch_size = std::stoi(optarg);
                } else if (strcmp(long_options[option_index].name, "optimize-memory") == 0) {
                    config.optimize_memory = true;
                } else if (strcmp(long_options[option_index].name, "disable-dev-fee") == 0) {
                    config.disable_dev_fee = true;
                } else if (strcmp(long_options[option_index].name, "stats-interval") == 0) {
                    config.stats_interval = std::stoi(optarg);
                } else if (strcmp(long_options[option_index].name, "log-level") == 0) {
                    config.log_level = optarg;
                } else if (strcmp(long_options[option_index].name, "log-file") == 0) {
                    config.log_file = optarg;
                }
                break;
            default:
                print_usage(argv[0]);
                return 1;
        }
    }

    if (config.url.empty()) {
        std::cerr << "ОШИБКА: URL сервера обязателен (-o)\n";
        print_usage(argv[0]);
        return 1;
    }

    try {
        Miner miner(config);
        miner.start();
        
        while (running) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        
        miner.stop();
        std::cout << "Майнер остановлен.\n";
        
    } catch (const std::exception& e) {
        std::cerr << "ОШИБКА: " << e.what() << std::endl;
        return 1;
    }

    return 0;
} 