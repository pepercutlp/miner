#pragma once

#include <vector>
#include <cstdint>
#include <memory>
#include <atomic>
#include <chrono>

// Условная компиляция для CUDA
#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <cublas_v2.h>
#else
// Заглушки для компиляции без CUDA
typedef void* cudaStream_t;
typedef void* cublasHandle_t;
#define cudaSuccess 0
#define cudaError_t int
#define cudaGetErrorString(x) "CUDA not available"
#define cudaMalloc(x, y) 0
#define cudaFree(x) 0
#define cudaMemcpy(x, y, z, w) 0
#define cudaDeviceReset() 0
#define cudaSetDevice(x) 0
#define cudaGetDeviceCount(x) 0
#define cudaGetDeviceProperties(x, y) 0
#define cudaDeviceSetLimit(x, y) 0
#define cudaStreamCreate(x) 0
#define cudaStreamDestroy(x) 0
#define cublasCreate(x) 0
#define cublasDestroy(x) 0
#endif

// Оптимизированные структуры данных для QHash
struct QHashWork {
    uint8_t header[80];
    uint8_t target[32];
    uint32_t nonce;
    uint32_t difficulty;
    uint64_t timestamp;
};

struct QHashResult {
    uint8_t hash[32];
    uint32_t nonce;
    bool valid;
    double difficulty;
};

class QHashEngine {
public:
    explicit QHashEngine(int gpu_threads = 1, int batch_size = 1024);
    ~QHashEngine();

    // Основные функции
    bool initialize();
    void cleanup();
    
    // Оптимизированные функции майнинга
    std::vector<QHashResult> mineBatch(const QHashWork& work, int iterations);
    QHashResult mineSingle(const QHashWork& work);
    
    // GPU оптимизации
    void setGPUMemory(int memory_mb);
    void setBatchSize(int batch_size);
    void setGPUThreads(int threads);
    
    // Статистика
    double getHashrate() const;
    uint64_t getTotalHashes() const;
    void resetStats();

private:
    int gpu_threads_;
    int batch_size_;
    int gpu_memory_mb_;
    
    // CUDA ресурсы
    cudaStream_t* streams_;
    cublasHandle_t cublas_handle_;
    void* gpu_memory_;
    size_t gpu_memory_size_;
    
    // Статистика
    std::atomic<uint64_t> total_hashes_{0};
    std::atomic<double> current_hashrate_{0.0};
    std::chrono::steady_clock::time_point last_update_;
    
    // Оптимизированные ядра
    bool initializeCUDA();
    void cleanupCUDA();
    void optimizeMemoryLayout();
    
    // Вспомогательные функции
    void updateHashrate();
    bool validateHash(const uint8_t* hash, const uint8_t* target);
};

// Оптимизированные CUDA ядра
extern "C" {
    void launch_qhash_kernel(
        uint8_t* header, 
        uint8_t* target,
        uint32_t* nonces,
        uint8_t* results,
        int batch_size,
        cudaStream_t stream
    );
    
    void launch_quantum_kernel(
        float* quantum_state,
        uint8_t* classical_data,
        int qubits,
        cudaStream_t stream
    );
} 