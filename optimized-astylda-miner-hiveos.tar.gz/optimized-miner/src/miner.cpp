#include "miner.h"
#include "qhash.h"
#include "network.h"
#include "api.h"
#include "utils.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <sstream>

Miner::Miner(const MinerConfig& config) : config_(config) {
    stats_.start_time = std::chrono::steady_clock::now();
    
    // Инициализация компонентов
    qhash_engine_ = std::make_unique<QHashEngine>(config.gpu_threads, config.batch_size);
    network_ = std::make_unique<NetworkManager>(config.url, config.user, config.pass);
    api_server_ = std::make_unique<APIServer>(config.api_port);
    
    if (config.optimize_memory) {
        optimizeMemoryUsage();
    }
}

Miner::~Miner() {
    stop();
}

void Miner::start() {
    if (running_) return;
    
    std::cout << "Запуск оптимизированного Astylda Miner v2.0..." << std::endl;
    std::cout << "Алгоритм: " << config_.algo << std::endl;
    std::cout << "URL: " << config_.url << std::endl;
    std::cout << "Потоки CPU: " << config_.threads << std::endl;
    std::cout << "Потоки GPU: " << config_.gpu_threads << std::endl;
    
    // Инициализация QHash движка
    if (!qhash_engine_->initialize()) {
        throw std::runtime_error("Ошибка инициализации QHash движка");
    }
    
    // Инициализация сети
    if (!network_->connect()) {
        throw std::runtime_error("Ошибка подключения к пулу");
    }
    
    // Запуск API сервера
    api_server_->start();
    
    running_ = true;
    
    // Запуск рабочих потоков
    for (int i = 0; i < config_.threads; ++i) {
        worker_threads_.emplace_back(&Miner::workerThread, this, i);
    }
    
    // Запуск потока статистики
    stats_thread_ = std::thread(&Miner::statsThread, this);
    
    // Запуск сетевого потока
    network_thread_ = std::thread(&Miner::networkThread, this);
    
    std::cout << "Майнер запущен успешно!" << std::endl;
}

void Miner::stop() {
    if (!running_) return;
    
    std::cout << "Остановка майнера..." << std::endl;
    running_ = false;
    
    // Ожидание завершения потоков
    for (auto& thread : worker_threads_) {
        if (thread.joinable()) {
            thread.join();
        }
    }
    
    if (stats_thread_.joinable()) {
        stats_thread_.join();
    }
    
    if (network_thread_.joinable()) {
        network_thread_.join();
    }
    
    // Очистка ресурсов
    qhash_engine_->cleanup();
    network_->disconnect();
    api_server_->stop();
    
    std::cout << "Майнер остановлен." << std::endl;
}

void Miner::workerThread(int thread_id) {
    // Установка CPU affinity если указано
    if (!config_.cpu_affinity.empty()) {
        setCPUAffinity(config_.cpu_affinity);
    }
    
    std::cout << "Поток " << thread_id << " запущен" << std::endl;
    
    QHashWork work;
    uint32_t nonce = thread_id * 1000000; // Уникальный начальный nonce для каждого потока
    
    while (running_) {
        try {
            // Получение работы от сети
            if (!network_->getWork(work)) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                continue;
            }
            
            // Установка nonce
            work.nonce = nonce++;
            
            // Майнинг батча
            auto results = qhash_engine_->mineBatch(work, config_.batch_size);
            
            // Проверка результатов
            for (const auto& result : results) {
                if (result.valid) {
                    // Отправка результата в сеть
                    if (network_->submitShare(result)) {
                        stats_.shares_accepted++;
                        std::cout << "✓ Шар принят! Nonce: " << result.nonce << std::endl;
                    } else {
                        stats_.shares_rejected++;
                        std::cout << "✗ Шар отклонен! Nonce: " << result.nonce << std::endl;
                    }
                }
            }
            
            // Обновление статистики
            updateStats();
            
        } catch (const std::exception& e) {
            std::cerr << "Ошибка в потоке " << thread_id << ": " << e.what() << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
    }
    
    std::cout << "Поток " << thread_id << " завершен" << std::endl;
}

void Miner::statsThread() {
    while (running_) {
        auto now = std::chrono::steady_clock::now();
        auto uptime = std::chrono::duration_cast<std::chrono::seconds>(now - stats_.start_time);
        stats_.uptime = uptime.count();
        
        // Обновление статистики API
        api_server_->updateStats(stats_);
        
        // Вывод статистики
        if (config_.stats_interval > 0) {
            static int counter = 0;
            if (++counter >= config_.stats_interval) {
                printStats();
                counter = 0;
            }
        }
        
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

void Miner::networkThread() {
    while (running_) {
        try {
            // Поддержание соединения
            network_->keepAlive();
            
            // Обработка сетевых событий
            network_->processEvents();
            
        } catch (const std::exception& e) {
            std::cerr << "Ошибка сетевого потока: " << e.what() << std::endl;
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void Miner::updateStats() {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    
    // Обновление хешрейта
    stats_.hashrate = qhash_engine_->getHashrate();
    
    // Обновление общего количества хешей
    uint64_t total_hashes = qhash_engine_->getTotalHashes();
    stats_.total_hashes = total_hashes;
}

MinerStats Miner::getStats() const {
    std::lock_guard<std::mutex> lock(stats_mutex_);
    return stats_;
}

void Miner::setCPUAffinity(const std::string& mask) {
    // Реализация установки CPU affinity
    std::cout << "Установка CPU affinity: " << mask << std::endl;
}

void Miner::optimizeMemoryUsage() {
    std::cout << "Оптимизация использования памяти..." << std::endl;
    
    // Настройка размера страниц
    if (config_.gpu_memory > 0) {
        qhash_engine_->setGPUMemory(config_.gpu_memory);
    }
    
    if (config_.batch_size > 0) {
        qhash_engine_->setBatchSize(config_.batch_size);
    }
}

void Miner::setGPUMemory(int memory_mb) {
    if (qhash_engine_) {
        qhash_engine_->setGPUMemory(memory_mb);
    }
}

void Miner::setBatchSize(int batch_size) {
    if (qhash_engine_) {
        qhash_engine_->setBatchSize(batch_size);
    }
}

void Miner::printStats() {
    auto stats = getStats();
    
    std::cout << "\n=== СТАТИСТИКА ===" << std::endl;
    std::cout << "Хешрейт: " << stats.hashrate << " MH/s" << std::endl;
    std::cout << "Принято шаров: " << stats.shares_accepted << std::endl;
    std::cout << "Отклонено шаров: " << stats.shares_rejected << std::endl;
    std::cout << "Найдено блоков: " << stats.blocks_found << std::endl;
    std::cout << "Время работы: " << stats.uptime << " сек" << std::endl;
    std::cout << "==================\n" << std::endl;
} 