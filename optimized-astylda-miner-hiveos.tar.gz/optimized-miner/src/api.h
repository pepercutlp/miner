#pragma once

#include <string>
#include <thread>
#include <atomic>
#include "miner.h"

class APIServer {
public:
    explicit APIServer(int port = 4048);
    ~APIServer();

    void start();
    void stop();
    void updateStats(const MinerStats& stats);

private:
    int port_;
    std::thread server_thread_;
    std::atomic<bool> running_;
    MinerStats current_stats_;
    
    void serverLoop();
    std::string generateStatsJSON() const;
    std::string handleRequest(const std::string& request) const;
}; 