#include "api.h"
#include <iostream>
#include <sstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

APIServer::APIServer(int port) : port_(port), running_(false) {
}

APIServer::~APIServer() {
    stop();
}

void APIServer::start() {
    if (running_) return;
    
    running_ = true;
    server_thread_ = std::thread(&APIServer::serverLoop, this);
    
    std::cout << "API сервер запущен на порту " << port_ << std::endl;
}

void APIServer::stop() {
    if (!running_) return;
    
    running_ = false;
    if (server_thread_.joinable()) {
        server_thread_.join();
    }
    
    std::cout << "API сервер остановлен" << std::endl;
}

void APIServer::updateStats(const MinerStats& stats) {
    current_stats_ = stats;
}

void APIServer::serverLoop() {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        std::cerr << "Ошибка создания сокета" << std::endl;
        return;
    }
    
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    
    struct sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(port_);
    
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        std::cerr << "Ошибка привязки сокета" << std::endl;
        close(server_fd);
        return;
    }
    
    if (listen(server_fd, 3) < 0) {
        std::cerr << "Ошибка прослушивания" << std::endl;
        close(server_fd);
        return;
    }
    
    while (running_) {
        int client_fd = accept(server_fd, nullptr, nullptr);
        if (client_fd < 0) {
            continue;
        }
        
        // Обработка запроса
        char buffer[1024] = {0};
        int bytes_read = read(client_fd, buffer, 1024);
        
        if (bytes_read > 0) {
            std::string request(buffer);
            std::string response = handleRequest(request);
            
            send(client_fd, response.c_str(), response.length(), 0);
        }
        
        close(client_fd);
    }
    
    close(server_fd);
}

std::string APIServer::generateStatsJSON() const {
    std::stringstream ss;
    ss << "{";
    ss << "\"hashrate\":" << current_stats_.hashrate << ",";
    ss << "\"hashrate_unit\":\"MH/s\",";
    ss << "\"shares_accepted\":" << current_stats_.shares_accepted << ",";
    ss << "\"shares_rejected\":" << current_stats_.shares_rejected << ",";
    ss << "\"blocks_found\":" << current_stats_.blocks_found << ",";
    ss << "\"uptime\":" << current_stats_.uptime << ",";
    ss << "\"total_hashes\":" << current_stats_.total_hashes;
    ss << "}";
    
    return ss.str();
}

std::string APIServer::handleRequest(const std::string& request) const {
    std::string response;
    
    if (request.find("GET /summary") != std::string::npos) {
        response = "HTTP/1.1 200 OK\r\n";
        response += "Content-Type: application/json\r\n";
        response += "Access-Control-Allow-Origin: *\r\n";
        response += "\r\n";
        response += generateStatsJSON();
    } else if (request.find("GET /") != std::string::npos) {
        response = "HTTP/1.1 200 OK\r\n";
        response += "Content-Type: text/html\r\n";
        response += "\r\n";
        response += "<html><body>";
        response += "<h1>Оптимизированный Astylda Miner v2.0</h1>";
        response += "<p><a href='/summary'>Статистика</a></p>";
        response += "</body></html>";
    } else {
        response = "HTTP/1.1 404 Not Found\r\n\r\n";
    }
    
    return response;
} 