#!/bin/bash

# Скрипт установки optimized-astylda-miner для HiveOS
# Устанавливает зависимости и собирает майнер

set -e

echo "=== Установка optimized-astylda-miner ==="

# Проверка ОС
if [[ "$(uname)" != "Linux" ]]; then
    echo "Ошибка: Этот скрипт предназначен только для Linux"
    exit 1
fi

# Обновление пакетов
echo "Обновление пакетов..."
sudo apt update

# Установка базовых зависимостей
echo "Установка базовых зависимостей..."
sudo apt install -y build-essential cmake git wget curl \
    libssl-dev libcurl4-openssl-dev libjson-c-dev libgmp-dev \
    libpthread-stubs0-dev bc jq netcat

# Проверка и установка CUDA
echo "Проверка CUDA..."
if ! command -v nvcc &> /dev/null; then
    echo "CUDA не установлена. Установка CUDA Toolkit..."
    
    # Определение версии Ubuntu
    ubuntu_version=$(lsb_release -rs)
    
    if [[ "$ubuntu_version" == "20.04" ]]; then
        # Ubuntu 20.04
        wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2004/x86_64/cuda-keyring_1.0-1_all.deb
        sudo dpkg -i cuda-keyring_1.0-1_all.deb
        sudo apt update
        sudo apt install -y cuda-toolkit-12-4
    elif [[ "$ubuntu_version" == "22.04" ]]; then
        # Ubuntu 22.04
        wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-keyring_1.0-1_all.deb
        sudo dpkg -i cuda-keyring_1.0-1_all.deb
        sudo apt update
        sudo apt install -y cuda-toolkit-12-4
    else
        echo "Предупреждение: Неподдерживаемая версия Ubuntu. Попробуйте установить CUDA вручную."
    fi
else
    echo "CUDA уже установлена: $(nvcc --version | head -1)"
fi

# Проверка GPU
echo "Проверка GPU..."
if command -v nvidia-smi &> /dev/null; then
    gpu_count=$(nvidia-smi --list-gpus | wc -l)
    echo "Найдено GPU: $gpu_count"
    nvidia-smi --list-gpus
else
    echo "Предупреждение: nvidia-smi не найден. GPU может быть недоступен."
fi

# Создание директорий
echo "Создание директорий..."
mkdir -p /hive/miners/custom/optimized-astylda
mkdir -p /var/log/miner

# Сборка майнера
echo "Сборка майнера..."
make clean
make -j$(nproc)

# Проверка сборки
if [[ -f optimized-astylda-miner ]]; then
    echo "Майнер успешно собран!"
    chmod +x optimized-astylda-miner
    
    # Копирование файлов
    echo "Копирование файлов..."
    cp optimized-astylda-miner /hive/miners/custom/optimized-astylda/
    cp h-*.sh /hive/miners/custom/optimized-astylda/
    cp h-manifest.conf /hive/miners/custom/optimized-astylda/
    chmod +x /hive/miners/custom/optimized-astylda/*.sh
    
    echo "=== Установка завершена успешно! ==="
    echo "Майнер: /hive/miners/custom/optimized-astylda/optimized-astylda-miner"
    echo "Скрипты: /hive/miners/custom/optimized-astylda/h-*.sh"
    echo ""
    echo "Для запуска используйте:"
    echo "cd /hive/miners/custom/optimized-astylda"
    echo "./h-run.sh"
else
    echo "Ошибка: Сборка не удалась"
    exit 1
fi 