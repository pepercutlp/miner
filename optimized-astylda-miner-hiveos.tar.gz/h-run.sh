#!/bin/bash

# Скрипт запуска optimized-astylda-miner для HiveOS
# Запускает майнер на всех доступных GPU

# Проверка наличия бинарника
if [[ ! -f ./$CUSTOM_MINERBIN ]]; then
    echo "Ошибка: Бинарник $CUSTOM_MINERBIN не найден"
    exit 1
fi

# Проверка конфигурационного файла
if [[ ! -f $CUSTOM_CONFIG_FILENAME ]]; then
    echo "Ошибка: Конфигурационный файл $CUSTOM_CONFIG_FILENAME не найден"
    exit 1
fi

# Получение количества GPU
gpu_count=$(nvidia-smi --list-gpus | wc -l)
if [[ $gpu_count -eq 0 ]]; then
    echo "Предупреждение: GPU не обнаружены, запуск на CPU"
    gpu_count=1
fi

echo "Найдено GPU: $gpu_count"

# Остановка предыдущих процессов
pkill -f $CUSTOM_MINERBIN

# Создание директории для логов
mkdir -p /var/log/miner

# Запуск майнера для каждого GPU
for ((i = 0; i < gpu_count; i++)); do
    # Расчет количества потоков CPU для каждого GPU
    cpu_cores=$(nproc)
    threads_per_gpu=$((cpu_cores / gpu_count))
    if [[ $threads_per_gpu -lt 1 ]]; then
        threads_per_gpu=1
    fi
    
    # Настройка имени screen сессии
    screenName="$CUSTOM_MINERBIN$i"
    apiPort="4444$i"
    log="/var/log/$CUSTOM_MINERBIN$i.log"
    
    # Формирование команды запуска
    batch="CUDA_VISIBLE_DEVICES=$i ./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) -t $threads_per_gpu --api-bind $apiPort"
    
    # Добавление дополнительных параметров если есть
    if [[ -f $CUSTOM_USER_CONFIG_FILENAME ]]; then
        remainingAddition=$(< $CUSTOM_USER_CONFIG_FILENAME)
        batch+=" $remainingAddition"
    fi
    
    echo "Запуск GPU $i: $batch"
    
    # Запуск в screen сессии
    screen -dmS $screenName bash -c "$batch 2>&1 | tee $log"
    
    # Небольшая задержка между запусками
    sleep 2
done

echo "Майнер запущен на $gpu_count GPU"
echo "Логи: /var/log/$CUSTOM_MINERBIN*.log"
echo "API порты: 44440-$((44440 + gpu_count - 1))" 